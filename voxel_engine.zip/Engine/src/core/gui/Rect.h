#pragma once

namespace Engine {

	struct Rect
	{
		Float2 min;
		Float2 max;

		//Rect(Float2 min, Float2 max)
	};

}